module.exports = (on, config) => {}
