import * as _d3 from 'd3';  // comment this line to run locally with http-server
export default typeof window === "object" && !!window.d3 ? window.d3 : _d3;